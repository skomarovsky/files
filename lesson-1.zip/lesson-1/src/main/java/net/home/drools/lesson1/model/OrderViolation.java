package net.home.drools.lesson1.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class OrderViolation {
    private String orderId;
    private List<String> ruleViolations;
}
