package net.home.drools.lesson1.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Account {
    private String accountNumber;
    private String accountStatus;
}