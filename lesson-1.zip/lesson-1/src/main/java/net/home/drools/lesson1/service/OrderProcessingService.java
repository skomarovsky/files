package net.home.drools.lesson1.service;

import jakarta.annotation.PreDestroy;
import net.home.drools.lesson1.model.Order;
import net.home.drools.lesson1.model.OrderViolation;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderProcessingService {
    private final KieContainer kieContainer;
    private final KieSession kieSession; // Create a single KieSession
    private static final Logger LOGGER = LoggerFactory.getLogger(OrderProcessingService.class);

    @Autowired
    public OrderProcessingService(KieContainer kieContainer) {
        this.kieContainer = kieContainer;
        this.kieSession = kieContainer.newKieSession(); // Initialize KieSession here
    }

    public List<OrderViolation> processOrders(Order[] orders) {
        List<OrderViolation> orderViolations = new ArrayList<>();

        try {
            for (int i = 0; i < orders.length; i++) {
                Order order = orders[i];
                OrderViolation violation = new OrderViolation();
                violation.setOrderId("orderArrayId_" + i);
                violation.setRuleViolations(new ArrayList<>());

                kieSession.insert(order);
                kieSession.setGlobal("orderViolation", violation);
            }

            kieSession.fireAllRules();
        } catch (Exception e) {
            LOGGER.error("Error processing orders: {}", e.getMessage());
            // Handle exceptions or log errors as needed.
        }

        return orderViolations;
    }

    // Dispose of the KieSession when the service is destroyed (e.g., during application shutdown)
    @PreDestroy
    public void destroy() {
        if (kieSession != null) {
            kieSession.dispose();
        }
    }
}