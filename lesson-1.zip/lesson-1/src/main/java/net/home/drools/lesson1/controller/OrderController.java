package net.home.drools.lesson1.controller;

import net.home.drools.lesson1.model.Order;
import net.home.drools.lesson1.model.OrderViolation;
import net.home.drools.lesson1.service.OrderProcessingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class OrderController {
    private static final Logger LOGGER = LoggerFactory.getLogger(OrderController.class);
    private final OrderProcessingService orderProcessingService;

    @Autowired
    public OrderController(OrderProcessingService orderProcessingService) {
        this.orderProcessingService = orderProcessingService;
    }

    @PostMapping("/processOrders")
    public List<OrderViolation> processOrders(@RequestBody Order[] orders) {
        LOGGER.info("Received {} orders for processing.", orders.length);
        List<OrderViolation> orderViolations = orderProcessingService.processOrders(orders);
        LOGGER.info("Processed orders. Found violations for {} orders.", orderViolations.size());
        return orderViolations;
    }
}
