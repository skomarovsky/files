package net.home.drools.lesson1.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Restriction {
    private String securityRestriction;
    private String securityCategoryRestriction;
}