package net.home.drools.lesson1.model;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Security {
    private String security;
    private String type;
    private String category;
}